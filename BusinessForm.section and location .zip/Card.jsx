import React, { useState } from 'react';
import styles from "./card.module.css";
import { FaBookmark } from "react-icons/fa";
import { CiBookmark } from "react-icons/ci";
import { CiLocationOn } from "react-icons/ci";
import { FaStar } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';
import useSaveListing from '../../utils/react-query-hooks/Listings/useSaveListing';
import useRemoveSavedListing from '../../utils/react-query-hooks/Listings/useRemoveSavedListing';
export default function Card({card}) {
    const [saved , setSaved] = useState(false);
    const [distance, setDistance] = useState(null);
    const navigate = useNavigate();
    const handleNavigate = ()=>{
        navigate(`/listing/${card._id}`)
    };
    const apiURL = import.meta.env.VITE_API_URL;

    // Calculate distance using the Haversine formula
    const calculateDistance = (lat1, lon1, lat2, lon2) => {
        const toRadians = (degrees) => (degrees * Math.PI) / 180;
        const R = 6371; // Earth's radius in km
        const dLat = toRadians(lat2 - lat1);
        const dLon = toRadians(lon2 - lon1);
        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distanceInKm = R * c; // Distance in km
        return distanceInKm;
    };

    // Get user's current location and calculate the distance
    useEffect(() => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const userLat = position.coords.latitude;
                    const userLon = position.coords.longitude;
                    const cardLat = card.location.latitude; // Assuming location has `latitude` and `longitude`
                    const cardLon = card.location.longitude;

                    const dist = calculateDistance(userLat, userLon, cardLat, cardLon);
                    setDistance(dist);
                },
                (error) => {
                    console.error("Error fetching user location:", error);
                }
            );
        }
    }, [card.location]);


    const getRoundRating = (reviews)=>{
        const totalRatings = card?.reviews?.reduce((sum, review) => sum + (review.rating || 0), 0);    
        const calculatedMean = card?.reviews?.length ? totalRatings / card?.reviews.length : null;
        return Number(calculatedMean).toFixed(1);
    }
    const onSaveSuccess = (data)=>{
        setSaved(true)
    }
    const onSaveError = (e)=>{
        setSaved(false);
    }
    const onRemoveSuccess = (data)=>{
        setSaved(false)
    }
    const onRemoveError = (e)=>{
        setSaved(true)
    }
    const saveListing = useSaveListing({onSaveSuccess,onSaveError});
    const removeSavedListing = useRemoveSavedListing({});
    const handleSaveListing = ()=>{
        saveListing.mutate(card._id)
    }
    const handleRemoveSavedListing = ()=>{
        removeSavedListing.mutate(card._id);
    }
  return (
    <div 
    className={`${styles.card} w-full flex flex-col items-center  bg-white shadow-xl rounded-xl  pb-4`}>
        <div className={`${styles.cardHeader} w-full relative text-white text-sm`}>
            <img src={`${apiURL}/${card.logo}`} alt='card img' className='max-w-full w-full h-60 object-cover' />
            {
                saved?
            <div className='absolute right-0 top-0 me-4 mt-4 bg-white rounded-full p-2' onClick={handleRemoveSavedListing}>
            <FaBookmark size={20} className='text-primaryA0'/>
            </div>
                :
            <div className='absolute right-0 top-0 me-4 mt-4 bg-white rounded-full p-2 hover:cursor-pointer' onClick={handleSaveListing}>
            <CiBookmark size={20} className='text-primaryA0'/>
            </div>
            }
            
            
            <div className='absolute bottom-0 left-0 ms-4 mb-4 rounded-bullet border border-white p-2 flex gap-1 items-center text-white '>
                <span><CiLocationOn size={20}/></span>
                {/* <span>{card.location}</span> */}
                <span>
                    {distance
                        ? distance < 1
                            ? `${(distance * 1000).toFixed(0)} meters away`
                            : `${distance.toFixed(1)} km away`
                        : card.location.address}
                </span>
            </div>
            <div className='absolute bottom-0 right-0 me-4 mb-4 flex items-center gap-1 py-2'>
                <span><FaStar className='text-yellow-400'/></span>
                <span>{getRoundRating(card?.reviews?.length)}</span>
                <span>({card?.reviews?.length} reviews)</span>
            </div>
        </div>
        <div className={`${styles.cardBody} w-full mt-4 px-4 hover:cursor-pointer`} onClick={handleNavigate}>
            <h5>{card.serviceTitle}</h5>
            <p className='font-light text-sm   text-wrap flex gap-2 max-w-full'>
                <span className='break-all'>{card.serviceDescription.substring(0,100)}</span>
                <span className='font-bold'>Read more</span>
            </p>
        </div>
    </div>
  )
}
