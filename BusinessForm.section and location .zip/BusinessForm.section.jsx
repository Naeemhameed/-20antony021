import React, { useState } from 'react'
import {useNavigate} from "react-router-dom";
import { useDispatch, useSelector} from "react-redux";
import { IoIosRemoveCircle } from "react-icons/io";
import { CiLocationOn } from "react-icons/ci";
import { handleFileChange } from '../../../utils/helperFunctions/handleFileChange';


export default function BusinessFormSection({setFormStep , register , errors  , setValue , trigger}) {
    const businessCard = useSelector(state=>state.listing.businessCard);
    const [selectedLogo, setSelectedLogo] = useState(null);
    const [services , setServices] = useState([]);
    const [serviceName, setServiceName] = useState("");

    const handleNextStep = async()=>{
        const isValid = await trigger([
            'logo',
            'businessTitle',
            'location',
            'services',
            'businessInfo',
            'businessWebsite',
            'street',
            'city',
            'zipcode',
            'country',
          ]);
        if(isValid){
            // Concatenate address fields into a single line
            const street = getValues('street'); // Fetch value from `react-hook-form`
            const city = getValues('city');
            const zipcode = getValues('zipcode');
            const country = getValues('country');

            const location = `${street}, ${city}, ${zipcode}, ${country}`.trim();

            // Set the concatenated value to `location`
            setValue('location', location);
            
            setFormStep((prevStep)=>prevStep +1);
        }
      }

    const handleAddService = ()=>{
        if(serviceName){
            setServices([...services,serviceName.trim()]);
            setValue("services",[...services,serviceName.trim()])
        }

    }
    const handleRemoveService = (name)=>{
        setServices(services.filter(s=>name === s))
        setValue("services",services.filter(s=>name === s))
    }

      
  return (
        <section className='flex flex-col py-10 capitalize items-center'>
            <div className='max-w-screen-lg  w-full'>
                <div className=' flex flex-col gap-4 items-start  mx-auto '>
                    <div className='w-4/6 flex flex-col gap-4 mx-auto'>
                    <div className='w-full h-full shadow-2xl px-4 py-3 flex flex-col  justify-around rounded-lg border'>
                                <div className='flex flex-col justify-center gap-10 items-center mb-3'>
                                   <div className='flex flex-col items-center justify-center gap-2'>
                                        <label htmlFor='logo' className='w-36 h-36 rounded-full flex items-center justify-center  border  hover:cursor-pointer'>  
                                        {  
                                            selectedLogo || businessCard?.logo?
                                            <img src={selectedLogo || businessCard?.logo} className='w-36 h-36 object-cover rounded-full' />
                                            :
                                            <>
                                            <span className='text-xs text-center font-semibold'>Upload your bussiness logo</span>
                                            </>
                                        }
                                        </label>
                                        <input 
                                        id='logo' 
                                        type='file'
                                        accept='image/*'  
                                        hidden 
                                        {...register("logo")}
                                        onChange={(e)=>handleFileChange(e,setSelectedLogo,setValue)}
                                        
                                        />
                                        {errors.logo && <p className="text-red-500">{errors.logo.message}</p>}
                                    </div>
                                    <div className='flex flex-col'>
                                        <input 
                                        placeholder='Business Title'
                                        type='text'
                                        id='businessTitle'
                                        className='border py-2 px-3'
                                        {...register("businessTitle")}
                                        />
                                        {errors.businessTitle && <p className="text-red-500">{errors.businessTitle.message}</p>}
                                    </div>
                                </div>
                                <hr/>
                                <div className='flex flex-col items-center gap-2 py-3'>
                                    <label>Add Your Address</label>
                                    <div className='flex flex-col gap-4 w-full'>
                                        <div className='flex gap-2 items-center'>
                                            <input
                                                type='text'
                                                id='street'
                                                placeholder='Enter street address'
                                                className='border py-2 px-3 w-full'
                                                {...register("street", { required: "Street is required" })}
                                            />
                                        </div>
                                        {errors.street && <p className="text-red-500">{errors.street.message}</p>}

                                        <div className='flex gap-2 items-center'>
                                            <input
                                                type='text'
                                                id='city'
                                                placeholder='Enter city'
                                                className='border py-2 px-3 w-full'
                                                {...register("city", { required: "City is required" })}
                                            />
                                        </div>
                                        {errors.city && <p className="text-red-500">{errors.city.message}</p>}

                                        <div className='flex gap-2 items-center'>
                                            <input
                                                type='text'
                                                id='zipcode'
                                                placeholder='Enter zip code'
                                                className='border py-2 px-3 w-full'
                                                {...register("zipcode", { 
                                                    required: "Zip Code is required", 
                                                    pattern: { 
                                                        value: /^[0-9]{5}(-[0-9]{4})?$/, 
                                                        message: "Invalid zip code" 
                                                    }
                                                })}
                                            />
                                        </div>
                                        {errors.zipcode && <p className="text-red-500">{errors.zipcode.message}</p>}

                                        <div className='flex gap-2 items-center'>
                                            <select
                                                id='country'
                                                className='border py-2 px-3 w-full'
                                                {...register("country", { required: "Country is required" })}
                                                defaultValue="Australia"
                                            >
                                                <option value="Australia">Australia</option>
                                                <option value="New Zealand">New Zealand</option>
                                            </select>
                                        </div>
                                        {errors.country && <p className="text-red-500">{errors.country.message}</p>}
                                    </div>
                                </div>

                                <hr/>
                                <div className='py-4 flex flex-col gap-4 items-center'>
                                    <label>enter other services</label>
                                    <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
                                        <input 
                                        type='text'
                                        placeholder='Service Name'
                                        className='py-2 px-3 border'
                                        value={serviceName}
                                        onChange={(e)=>{setServiceName(e.target.value)}}
                                        />
                                        <button
                                        type='button'
                                        className='btn-black'
                                        onClick={handleAddService}>add service</button>
                                        {errors.services && <p className="text-red-500">{errors.services.message}</p>}
                                    </div>
                                    <ul>
                                        {services?.map((s,i)=>{
                                           return <li  className='flex gap-3 items-center' key={i}>
                                            <span>{s}</span>
                                            <span
                                            className='hover:cursor-pointer text-red-500'
                                             onClick={handleRemoveService}><IoIosRemoveCircle /></span>
                                            </li>
                                            })}
                                    </ul>
                                </div>
                                <hr/>
                                <div className='py-4 mx-auto w-full'>
                                    <textarea
                                    rows={3}
                                    type='text'
                                    className='py-2 px-3 border mx-auto w-full rounded-lg'
                                    placeholder='Business Info'
                                    {...register("businessInfo")}
                                    />
                                    {errors.businessInfo && <p className="text-red-500">{errors.businessInfo.message}</p>}
                                </div>
                                <hr/>
                                <div className='py-4 mx-auto'>
                                    <input
                                    type='text'
                                    className='py-2 px-3 border mx-auto '
                                    placeholder='Business Website'
                                    {...register("businessWebsite")}
                                    />
                                    {errors.businessWebsite && <p className="text-red-500">{errors.businessWebsite.message}</p>}
                                </div>
                            </div>
                        <div className='md:ms-auto  flex flex-col md:flex-row gap-3'>
                            <button className='btn-primary' type='button' onClick={handleNextStep}>service Information</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
  )
}
